let a=12, b=20,i=2;
do{
    console.log(a+b);
    i--;
}while(i>0)