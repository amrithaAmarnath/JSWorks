var fromBox = document.querySelector('#id_select1');
var toBox = document.querySelector('#id_select2');
var currencyCode;

fetch(`https://v6.exchangerate-api.com/v6/ab727fc9b0f0e672f8a9b0fe/latest/USD`).then(res=>res.json())
.then(data=>processData(data));

function processData(data){
    currencyCode=data.conversion_rates;
    for(countryCodes in currencyCode){
        fromBox.appendChild(getOptionTag(countryCodes))
        toBox.appendChild(getOptionTag(countryCodes))

   }
  }

function getOptionTag(code){
                let optionTag=document.createElement('option');
               // console.log(code)
                optionTag.value=currencyCode[code];
                optionTag.text=code;
                return optionTag
}

function exchange(){
    let fromRate=document.querySelector("#id_select1").value;
    let toRate=document.querySelector("#id_select2").value;
    console.log(fromRate,toRate);
   // console.log(currencyCode)
    let amount=id_amount.value
   // console.log(fromRate)
   let finalValue =
   ((amount / fromRate) * toRate).toFixed(2);
   console.log(finalValue);
   document.querySelector("#id_result").innerHTML=finalValue;
}

function displayCountryName(event){
    let cname=event.options[event.selectedIndex].text;
    console.log(cname)
}